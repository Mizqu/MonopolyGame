﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WJPMonopoly
{
    /// <summary>
    /// Logika interakcji dla klasy Game_configwindow.xaml
    /// </summary>
    public partial class Game_configwindow : Window
    { 
        
        public Game_configwindow()
        {
            InitializeComponent();
        }

        private void myComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            ComboBox comboBox = (ComboBox)sender; 
            ComboBoxItem selectedItem = (ComboBoxItem)comboBox.SelectedItem; 

            if (selectedItem != null)
            {               
                string selectedValue = selectedItem.Content.ToString();
                int number_of_players = Convert.ToInt32(selectedValue);
                List<int> players = new List<int>(number_of_players);

                for (int i = 0; i < number_of_players ; i++)
                {
                    players.Add(i);
                }

                GameWindow win = new GameWindow(players) ;
                Close();
                win.Show();
            }
        }

    }
}
