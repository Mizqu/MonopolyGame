﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WJPMonopoly
{
    internal class PlayerAttribute
    {
        public int money { get; set; }
       
        public int turn { get; set; }

    }
}
