﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WJPMonopoly
{
    internal class GameState
    {
        public List<int> players { get; set; }
        public int current_turn { get; set; }   
        public List<PlayerAttribute> attributes { get; set; }
        
        public GameState(List<int> players)
        {
            this.players = players;
            
        }

        public void CreatePlayers(List<int> players)
        {
            attributes = new List<PlayerAttribute>(players.Count);

            for (int i = 0; i < players.Count; i++)
            {
                PlayerAttribute attribute = new PlayerAttribute();
                attribute.turn = players[i];
                attributes.Add(attribute);
            }
        }
        public int turn(int player_turn)
        {
            return player_turn;
        }
    }
}
